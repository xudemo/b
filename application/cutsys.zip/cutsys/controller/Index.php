<?php
namespace app\cutsys\controller;

use think\Controller;
use think\Db;

class Index extends Controller{
    public function index(){
        Db::connect('db_config1');
    }
}